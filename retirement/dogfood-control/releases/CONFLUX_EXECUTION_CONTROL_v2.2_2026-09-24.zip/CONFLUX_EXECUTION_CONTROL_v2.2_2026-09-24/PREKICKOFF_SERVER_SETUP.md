# Pre-Kickoff Server Setup

External VM/control setup only. Keep /home/conflux and /home/conflux-worktrees absent until kickoff. Do not clone/init Git, create product files, start BOOT-B00, or commit before 2026-09-25 18:00 UTC.

Control root: /home/dogfood-control/execution. Plan root: /home/dogfood-control/plan. Future repo/worktrees: /home/conflux and /home/conflux-worktrees. Export CONFLUX_CONTROL_ROOT, CONFLUX_PLAN_ROOT, CONFLUX_WORKTREE_ROOT, CONFLUX_REPO_ROOT in login shells and tmux global environment; store no secrets there.

Use /home/dogfood-control/bin/conflux-control; it must work before the product repo exists. Keep the pinned source Freebuff build; do not update/reinstall, enable custom agents, or touch owner-managed authentication. Verify cached storage images are ARM64. RustFS default, SeaweedFS compatibility profile, ZeroS3 optional. Preserve disk/swap and existing Docker/Python/Node/Codex caches.
