# Participant My Event — design/participant-my-event (r1)
**Boards**: MyEvent (desktop), MyEvent-Mobile (action-needed + ready)
**Standalone HTML**: `html/` · **Screenshots**: `screenshots/` · **Live source**: `../../exports/r1/canvas/project/`

## Must preserve
- Ordered next-actions list with one primary; progress track; team/project block; personalized schedule with Now marker; event pass QR with offline save; where/help/what-happens-next; explicit "You're ready" state.
- Hub is derived from canonical state only.

## Adaptable implementation details
- Which cards appear depends on enabled features; copy; ordering rules beyond urgency.

## Keyboard / focus / a11y
- Progress track is an ordered list with aria-current=step; countdowns have text equivalents; QR has alt text and printable fallback.

## Known limitations
- Wallet pass shown as button only.
