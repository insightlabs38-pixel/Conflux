# Judge review — design/judge-review (r1)
**Boards**: Judge-Review, Judge-Dialogs (recusal, flag, route, offline/conflict), Judge-Mobile
**Standalone HTML**: `html/` · **Screenshots**: `screenshots/` · **Live source**: `../../exports/r1/canvas/project/`

## Must preserve
- Queue | evidence | rubric; frozen-evidence tag; pinned autosave state; recusal + flag always reachable; submit disabled until complete with reason; keyboard scoring (1–5, Tab, ⌘↵, J/K, F, R); pacing indicator; route/current stop; offline buffer with deterministic reconcile.

## Adaptable implementation details
- Rubric anchor display (inline vs popover); queue sort options.

## Keyboard / focus / a11y
- Score scales are radiogroups; unscored criterion highlighted with text; shortcuts are discoverable and disable-able.

## Known limitations
- Pairwise mode not designed (see D-007).
