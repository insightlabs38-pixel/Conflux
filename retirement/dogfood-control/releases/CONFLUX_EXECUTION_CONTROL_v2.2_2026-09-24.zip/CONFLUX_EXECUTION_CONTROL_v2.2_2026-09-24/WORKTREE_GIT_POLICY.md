# Worktree and Git Policy

After kickoff, canonical repo is /home/conflux and isolated worktrees are /home/conflux-worktrees. Keep both absent before kickoff; never create product branches early.

Branch examples: claude/<batch-id>, sol/<batch-id>, luna/<task-id>, freebuff/<task-id>, fix/<id>. Clearly distinguish Sol from Luna.

Senior sessions own coherent batch branches; bulk sessions own one task branch/worktree per lease. Reservations record lane, ID, branch, worktree, start timestamp and optional session ID. Never share an index/worktree among writers. Use conflux-control for claims and transitions.
