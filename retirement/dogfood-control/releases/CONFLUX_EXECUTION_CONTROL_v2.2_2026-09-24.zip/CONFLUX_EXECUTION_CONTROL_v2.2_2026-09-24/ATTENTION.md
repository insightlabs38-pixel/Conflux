# NEEDS HUMAN ATTENTION

Pre-kickoff:
- Resolve/ask organizer whether the released checker intentionally has no T3/T4 assertions (nonblocking).
- At H0/H1, measure Sol + Luna #1 quota/useful throughput before enabling additional Luna capacity.
- Use owner-controlled Claude/Freebuff authentication only when needed; this setup did not touch authentication.

Keep this file concise and actionable during the event.
