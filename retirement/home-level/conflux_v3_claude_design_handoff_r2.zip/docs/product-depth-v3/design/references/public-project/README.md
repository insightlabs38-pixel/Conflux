# Public project — design/public-project (r2 · unchanged from r1)
**Boards**: Public-Project, Public-Project-Mobile
**Standalone HTML**: `html/` · **Screenshots**: `screenshots/` · **Live source**: `../../exports/r2/canvas/project/`

## Must preserve
- Reading column ≤68ch serif; metadata card panel; version switch (Living vs As judged) with banner; numbered math, code with filename/copy, figures with captions/alt/long description, benchmark table; references; on-this-page nav; responsive media and in-box scroll for wide math/code.

## Adaptable implementation details
- Sidebar contents per project metadata; OpenGraph card.

## Keyboard / focus / a11y
- Figures have alt text + long description link; code/math scroll inside container; sticky TOC does not trap focus.

## Known limitations
- Long-description and MathML output not drawn.
