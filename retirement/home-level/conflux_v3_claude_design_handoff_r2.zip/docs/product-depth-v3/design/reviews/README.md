# Reviews
- `CONFLUX_R1_DESIGN_REVIEW.md` — owner review of r1 and the r2 plan (the r2 prompt refers to it as `R1_OWNER_REVIEW_AND_R2_PLAN.md`; same document, stored under this name).
- `R2_BOARD_QA.md` — manual per-board QA ledger for r2.
