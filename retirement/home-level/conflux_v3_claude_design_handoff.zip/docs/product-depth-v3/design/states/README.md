# State matrix (design/state-matrix, r1)
Boards: `html/States-1.html` (normal, loading, empty, partial, error, permission-denied) and `html/States-2.html` (validation, large/dense, destructive, mobile, offline/degraded). Screenshots in `screenshots/`.
Each state class has one rule; each UI task must implement the rule on its surface. Rules are listed in the left column of every row.
Known limits: representative surfaces only (grid, My Event, judge, deliberation, story, public project, builder, pass); other surfaces inherit the rule.
