# D-008 · Dark mode
**Status**: accepted (r2)
**Decision**: Dark is a per-user preference (*system / light / dark*, default system) for authenticated app surfaces. Public event/project pages follow organizer theme tokens and are never overridden by the viewer's app theme; "Dark base" is an organizer-selectable public preset, contrast-checked at save.
**Rules**: same tokens/geometry/accent; theme root re-declares `color` and `background-color`; raised layers (popover, dialog, palette) use surface-2 with a light 1px edge and stronger shadow; primary-on-accent text uses `--accent-ink`; QR/badges stay light.
**Evidence**: Sys-Dark + four dark boards; lowest measured text pair 5.37:1; control border line-3 4.62:1. Dark comps found three r1 token bugs (inherited ink, hard-coded white/greys, flat elevation).
**Open**: `.btn` border (line-2) is ~1.7:1 in both themes; label identifies the control. Choose line-3 buttons if owner prefers stricter 1.4.11 reading.
