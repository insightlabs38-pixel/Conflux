# Claude Code Senior-Batch Protocol

Claude Code local is the primary senior reasoning lane and remains owner-controlled. No other lane authenticates, manipulates or schedules through the owner's Claude session. Select coherent batches using conflux-control next-batch claude and reserve atomically.

Use for architectural invariants, authorization/security, concurrency, normalization/math, difficult root cause, critical semantic regressions and major gates. Claude is senior-batch only by default. Implementation agents write focused semantic tests; bulk verification lanes (Freebuff/Luna) own breadth. Claude retains critical semantic regressions and gates. Canonical queue/ownership edits go through conflux-control or explicit human/integration recovery.
