# Freebuff Serial Bulk Task Protocol

Freebuff is one serial top-level bulk lane. Normal model: GLM 5.3 Flash. Consume one READY bulk task at a time using conflux-control next-task freebuff, then atomically claim it. Never create another top-level Freebuff session.

Provider-supplied built-in helpers exposed by the installed working version may assist inside this session with code search, file discovery, web/docs research, shell/bash or review/thinking. This does not authorize custom user-defined agents. Custom agents are disabled because the current provider returns HTTP 403. Do not invoke them or try to repair the provider failure.

Never control Claude/Codex, type into another agent's tmux pane, or inspect another agent's private transcript. Never mutate canonical queue/ownership YAML directly; use conflux-control or explicit human/integration recovery.

DeepSeek V4.1 Flash spends Freebucks and requires explicit owner authorization or an explicitly owner-approved rule. Never spend Freebucks autonomously. GPT-6 Luna through Freebuff is contingency routing, not default.

Retry policy: one GLM attempt and one bounded correction only for a clearly mechanical defect. If reasoning-limited, seek owner-authorized DeepSeek or escalate by problem class to Luna/Sol/Claude. Leave a concise receipt with lane, model, worktree, focused tests and outcome.
