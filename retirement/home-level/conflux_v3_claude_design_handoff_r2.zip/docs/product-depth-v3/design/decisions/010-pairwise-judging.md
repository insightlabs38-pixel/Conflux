# D-010 · Pairwise judging
**Status**: accepted (r2) — supersedes the "split the centre pane" note.
- Dedicated layout: pair queue | aligned A/B evidence (linked scroll, sticky frozen labels, structured-field facts) | decision panel.
- Decisions: A/B; tie only if configured (cap shown, disabled with reason when forced-choice); skip; recuse from A or B; one key press saves with 10 s undo and auto-advance.
- Criterion context is one line; no dual rubrics. Nothing is coloured better/worse. Order randomised per judge.
- Adaptive counts are shown honestly (12 of 40, range 34–46) with "why this pair?".
- Hybrid: rubric → close-call detection → tiebreak pairs; rubric scores of A/B hidden during tiebreak; feeds only the tiebreaker row in Deliberation.
- Narrow: <768 A/B/Compare tabs + sticky decision bar; 768–1023 two columns + docked bar.
**Refs**: Pairwise-Compare, Pairwise-States, Pairwise-Narrow.
