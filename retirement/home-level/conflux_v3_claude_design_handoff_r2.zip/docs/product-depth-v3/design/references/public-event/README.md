# Public event — design/public-event (r2 · unchanged from r1)
**Boards**: Public-Event (no artwork), Public-Event-Themed (organizer theme, standard hero), Public-Event-Mobile
**Standalone HTML**: `html/` · **Screenshots**: `screenshots/` · **Live source**: `../../exports/r2/canvas/project/`

## Must preserve
- Compact hero default with typographic fallback; status + one primary action; results near top when published; project gallery (cards allowed here); tracks/schedule/sponsors/resources; theme limited to accent+bg with contrast validation.

## Adaptable implementation details
- Section order (block-driven), card content, sponsor tier layout.

## Keyboard / focus / a11y
- Landmarks (nav/main/footer), h1 once, colour contrast validated, focus visible on themed accents.

## Known limitations
- Immersive hero not drawn.
