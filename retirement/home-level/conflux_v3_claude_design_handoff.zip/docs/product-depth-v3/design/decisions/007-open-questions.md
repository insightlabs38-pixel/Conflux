# D-007 · Unresolved design questions (owner input wanted)
1. **Brand mark**: "C" monogram is a placeholder; confirm Conflux logo/wordmark.
2. **Font hosting**: confirm Plex/Source Serif licensing acceptable to self-host (OFL) or choose system stack for air-gapped installs.
3. **Density default for organizers**: standard (36) is default; consider dense default on ≥1920px displays.
4. **Wallet pass** (Apple/Google) is drawn as a button only; confirm scope.
5. **Immersive hero** and organizer custom CSS were intentionally not designed beyond the Advanced entry point.
6. **Realtime co-editing** presence chip is shown in the story editor; full collaborative cursor design deferred (EXPERT tier).
7. **Pairwise judge mode** only specified as "centre pane splits to two evidence columns" — needs a dedicated refinement board before the pairwise batch.
8. **Localization/RTL** not exercised in prototypes.
