# Decisions index
001 direction · 002 shell/inspector/routes · 003 data grid · 004 status/colour/a11y · 005 public hero/versions · 006 onsite mobile · 007 open questions.
