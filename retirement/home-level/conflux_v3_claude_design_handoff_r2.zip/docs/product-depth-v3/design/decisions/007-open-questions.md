# D-007 · Unresolved design questions (owner input wanted)
1. **Brand mark**: "C" monogram is a placeholder; confirm Conflux logo/wordmark.
2. **Font hosting**: confirm Plex/Source Serif licensing acceptable to self-host (OFL) or choose system stack for air-gapped installs.
3. **Density default for organizers**: r2 recommendation — keep Standard as the default, offer Dense once at ≥1800px (D-009). Owner to confirm.
4. **Wallet pass** (Apple/Google) is drawn as a button only; confirm scope.
5. **Immersive hero** and organizer custom CSS were intentionally not designed beyond the Advanced entry point.
6. **Realtime co-editing** presence chip is shown in the story editor; full collaborative cursor design deferred (EXPERT tier).
7. ~~Pairwise judge mode~~ — **resolved in r2** (D-010). Remaining: tie-share cap default and whether strength-of-preference ships.
8. **Localization/RTL** not exercised in prototypes.
9. (r2) `.btn` default border contrast: keep line-2 (label identifies) or move to line-3 (D-008).
10. (r2) Confirm the public "Dark base" preset should exist at all, or leave dark public pages to custom organizer tokens.

## Intentionally deferred (r2)
Final logo/brand mark · immersive hero beyond its Advanced entry · full wallet-pass internals · live collaborative cursors · exhaustive RTL/localization · every later Product Depth v3 surface (see `../LATER_DESIGN_PASSES.md`).
