# Conflux v3 design handoff (r1)
Start here: `DESIGN_MANIFEST.yaml` → `system/README.md` → `decisions/` → `references/<x>/README.md` (+ `screenshots/`, `html/`).
`exports/r1/canvas/project/` is the native Claude Design project (open `Main.dc.html`/`canvas.json`); `exports/r1/tools/build-exports.mjs` regenerates standalone HTML + screenshots.
Implementation agents: follow must-preserve intent; do not copy prototype CSS verbatim; map components via `system/component-mapping.md`.
