# Organizer data surface — design/organizer-data-surface (r1)
**Boards**: Data-Surface, Data-Filters
**Standalone HTML**: `html/` · **Screenshots**: `screenshots/` · **Live source**: `../../exports/r1/canvas/project/`

## Must preserve
- Grid + right inspector; saved-view control with modified/reset/save/copy link; chips + nested group affordance + equivalent query line; group rows with aggregates; selection bar with frozen-snapshot bulk plan; async job banner; inline cell edit with validation; dense 28px rows and virtualization footer; keyboard hint bar.

## Adaptable implementation details
- Column set per page; which actions sit in the bulk bar (max 4 + More); chip visual details; job banner placement (may live in Operations).

## Keyboard / focus / a11y
- role=grid, roving tabindex, aria-rowcount, sortable headers with aria-sort, selection announced ("3 selected"), inspector focus return.

## Known limitations
- Board view is only named (List/Board toggle), not designed. Column resize/reorder handles not drawn.
