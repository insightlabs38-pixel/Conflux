# Project story editor — design/project-story-editor (r1)
**Boards**: Story-Editor (split), Story-Rich (WYSIWYM + comments/suggestions), Story-History (diff, judged vs living)
**Standalone HTML**: `html/` · **Screenshots**: `screenshots/` · **Live source**: `../../exports/r1/canvas/project/`

## Must preserve
- Source/Split/Rich share one document model; exact Public/Judge/Frozen preview switch; structured sections with required/recommended and visibility; metadata cards (repo/demo/dataset/paper/model/license); preflight with blocking vs advisory; autosave state; comments anchored to block IDs; suggestions accept/reject; immutable revisions; judged r3 vs living diff.

## Adaptable implementation details
- Toolbar contents, slash menu items, exact lint rule set (event-configurable).

## Keyboard / focus / a11y
- Editor is a labelled textbox/contenteditable with accessible toolbar; alt-text and heading lint; math has text alternative.

## Known limitations
- Real-time cursors and mermaid/diagram rendering are not drawn.
