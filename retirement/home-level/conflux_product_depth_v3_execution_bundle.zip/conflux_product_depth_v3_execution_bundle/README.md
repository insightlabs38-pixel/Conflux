# Conflux Product Depth v3 — Execution Bundle

This is the activation-ready control bundle for the Product Depth v3 program.

**Current state: FROZEN. Do not start implementation until `ACTIVATION_PROCEDURE.md` is executed deliberately.**

## Canonical planning files

- `BATCHES.yaml`
- `TASKS.yaml`
- `docs/product-depth-v3/EXECUTION_PRINCIPLES.md`
- `docs/product-depth-v3/PRIMITIVE_REGISTRY.yaml`
- `docs/product-depth-v3/SPEC_INDEX.yaml`
- `docs/product-depth-v3/specs/`
- `docs/product-depth-v3/design/`

## Canonical execution-control files

- `docs/execution-v3/CONTROLLER_PROTOCOL.md`
- `docs/execution-v3/COMPLETION_RULES.md`
- `docs/execution-v3/RESUMABILITY_PROTOCOL.md`
- `docs/execution-v3/LOCKING_AND_PARALLELISM.md`
- `docs/execution-v3/ESCALATION_PROTOCOL.md`
- `docs/execution-v3/CHECKPOINT_AND_HANDOFF_PROTOCOL.md`
- `docs/execution-v3/EXECUTOR_POLICY.yaml`
- `docs/execution-v3/ACTIVATION_PROCEDURE.md`
- `docs/execution-v3/LEGACY_INTEGRATION_POLICY.md`
- `docs/execution-v3/RECEIPT_SCHEMA_V3.yaml`
- `docs/execution-v3/ESCALATION_SCHEMA.yaml`
- `docs/execution-v3/HANDOFF_SCHEMA.yaml`
- `docs/execution-v3/CHECKPOINT_SCHEMA.yaml`
- `docs/execution-v3/state/PROGRAM_STATE.yaml`

## Prompts

- `prompts/STANDARD_IMPLEMENTATION_PROMPT.md`
- `prompts/CLAUDE_DESIGN_FOUNDATION_PROMPT.md`

## Tooling

- `scripts/pdv3/validate_queue.py`
- `scripts/pdv3/task_context.py`
- `scripts/pdv3/ready_tasks.py`
- `scripts/pdv3/lint_receipt.py`
- `scripts/pdv3/recovery_report.py`
- `scripts/pdv3/activate.py`

## Core operating principle

`TASKS.yaml` and `BATCHES.yaml` define the plan. Workers implement one assigned task in an isolated branch/worktree. The controller is the only authority that:
- claims work;
- arbitrates locks;
- integrates branches;
- changes runtime task/batch status;
- marks tasks or batches DONE.

A worker may report `candidate_complete`; it may not self-certify DONE.

Runtime state is recorded under `docs/execution-v3/state/`, claims, receipts, handoffs, checkpoints and Git. A controller restart must reconstruct the campaign from those artifacts rather than from in-memory state.

## Compact-report invariant

Human batch receipts and worker final reports are **25 physical lines maximum**. Evidence belongs in structured receipts, committed tests/artifacts and exact command output references—not in long narrative status reports.

## First executable batch

After activation, `PD-R00` reconciles the merged legacy/new execution system before `PD-B00` begins the substantive product baseline.
