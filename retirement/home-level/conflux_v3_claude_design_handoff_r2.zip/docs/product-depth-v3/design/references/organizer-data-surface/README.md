# Organizer data surface — design/organizer-data-surface (r2)
**Boards**: Data-Surface, Data-Filters
**Standalone HTML**: `html/` · **Screenshots**: `screenshots/` · **Live source**: `../../exports/r2/canvas/project/`

## Must preserve
- Grid + right inspector; saved-view control with modified/reset/save/copy link; chips + nested group affordance + equivalent query line; group rows with aggregates; selection bar with frozen-snapshot bulk plan; async job banner; inline cell edit with validation; dense 28px rows and virtualization footer; keyboard hint bar.

## Adaptable implementation details
- Column set per page; which actions sit in the bulk bar (max 4 + More); chip visual details; job banner placement (may live in Operations).

## Keyboard / focus / a11y
- role=grid, roving tabindex, aria-rowcount, sortable headers with aria-sort, selection announced ("3 selected"), inspector focus return.

## Known limitations
- Board view is only named (List/Board toggle), not designed. Column resize/reorder handles not drawn.

## r2 changes
- Data-Filters artboard trimmed to 1350×1000 (r1 had a dead strip on the right). Data-Surface unchanged.
- New companions: `../responsive-wide/` **Resp-1024** (docked inspector, two-line name cell, folded toolbar) and **Wide-1920** (5,012-person stress fixture, 10 columns, inspector stays 420px). Dark: `../dark-mode/Dark-Organizer`.
- Must preserve (added): extra width is spent on columns and readable values, never on stretched inspector/cards; at ≥1800 suggest Dense once (per-user); virtualization cues (row window, tiny thumb, server-side sort/query) are visible.
- Known limitations: Data-Surface has a stray hairline fragment on the cursor row at the inspector edge; Changed column is tight at 1440.
