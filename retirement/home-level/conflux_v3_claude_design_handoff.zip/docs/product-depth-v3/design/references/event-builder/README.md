# Event builder — design/event-builder (r1)
**Boards**: Builder-Setup, Builder-Pages, Builder-Plan
**Standalone HTML**: `html/` · **Screenshots**: `screenshots/` · **Live source**: `../../exports/r1/canvas/project/`

## Must preserve
- Essentials vs Advanced with collapsed advanced groups; setup checklist; diagnostics rail with jump-to-field and fixes; live preview; unapplied-changes bar → plan; impact table; Event-as-Code diff parity; schema-driven extension form with permissions, https validation and test connection; hero style control with contrast-validated theme tokens.

## Adaptable implementation details
- Section names/order, which fields are Advanced, extension form field widgets.

## Keyboard / focus / a11y
- Errors linked from summary; every diagnostic focuses its field; plan buttons state prerequisites.

## Known limitations
- Drag-reorder affordances drawn, not specified in detail.
