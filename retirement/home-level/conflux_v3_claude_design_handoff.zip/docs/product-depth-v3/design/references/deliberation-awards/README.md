# Deliberation & awards — design/deliberation-awards (r1)
**Boards**: Deliberation, Deliberation-Finalize
**Standalone HTML**: `html/` · **Screenshots**: `screenshots/` · **Live source**: `../../exports/r1/canvas/project/`

## Must preserve
- Finalist table with normalized + raw + raw-rank shift + spread + coverage + per-award eligibility + stance; close-call marker; criterion compare; deterministic "why A over B"; sensitivity; notes with author/time/visibility; recusal; override needs category + reason; approvals with no-self-approve; plan → approve → apply; exact publication preview; immutable receipt.

## Adaptable implementation details
- Number of finalists shown, weights display, sensitivity scenarios list.

## Keyboard / focus / a11y
- Table twin for spread glyphs; disabled Apply explains why; dialogs restore focus.

## Known limitations
- Evidence graph link is a placeholder.
