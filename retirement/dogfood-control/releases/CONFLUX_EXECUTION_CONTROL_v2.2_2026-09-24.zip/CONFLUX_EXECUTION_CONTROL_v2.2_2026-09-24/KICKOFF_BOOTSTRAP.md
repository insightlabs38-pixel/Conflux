# Kickoff Bootstrap

Before 2026-09-25 18:00 UTC: no clone, Git initialization, product files/scaffolds/manifests/Compose, BOOT-B00 or product commit.

At/after H0:
1. Human confirms the official window and performs legal repository bootstrap (BOOT-B00).
2. Establish main and verify blank repository state.
3. Sol and Claude begin coherent senior batches through atomic reservations.
4. Start one Luna bulk task lane and one Freebuff GLM serial task lane.
5. Probe Sol + Luna #1 on independent real tasks; unlock Luna #2/#3 only from measured quota and healthy integration/review.
6. External deterministic controller enables atomic claims and status; there is no AI orchestrator.
7. Keep Freebuff to one top-level task. Claude Cloud remains owner-controlled reserve.
