# D-009 · Intermediate and wide responsive rules
**Status**: accepted (r2)
- ≥1800: same shell; inspector stays 420; extra width → more columns / wider values; offer Dense once; no stretched cards; no second pane on the data surface.
- 1440–1799: rail 216 + grid + inspector 372–420.
- 1024–1439: rail 52 icons; inspector **docked push** 340–380; grid uses priority columns and a two-line name cell; toolbar folds secondary controls into View; 44px rows on touch.
- 768–1023: top bar + drawer nav; two-pane workflows keep both panes and move the third into a drawer; inspector becomes a full-height sheet; targets ≥44px.
- <768: task-specific layouts (unchanged).
**Density**: account default remains Standard; never auto-switch by viewport.
**Refs**: Resp-1024, Resp-768, Wide-1920 (5,012-person fixture).
