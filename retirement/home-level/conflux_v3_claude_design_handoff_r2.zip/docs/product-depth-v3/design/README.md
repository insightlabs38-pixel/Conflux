# Conflux v3 design handoff (r2)
Start here: `DESIGN_MANIFEST.yaml` → `system/README.md` → `decisions/` → `references/<x>/README.md` (+ `screenshots/`, `html/`). QA: `reviews/R2_BOARD_QA.md`. Owner review that drove r2: `reviews/CONFLUX_R1_DESIGN_REVIEW.md`. Later design passes: `LATER_DESIGN_PASSES.md`.
- `exports/r2/canvas/project/` is the native Claude Design project (`Main.dc.html`, `canvas.json`, 45 boards). `exports/r2/tools/build-exports.mjs --shots` regenerates standalone HTML + screenshots (`sync-canvas.py` keeps canvas.json in step).
- `exports/r1/` preserves the r1 revision: native canvas, index board, and `published/` (r1 HTML + screenshots as delivered).
- `prompts/` holds the exact prompts that produced each pass.
Implementation agents: follow must-preserve intent; do not copy prototype CSS verbatim; map components via `system/component-mapping.md`.
