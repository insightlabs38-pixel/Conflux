# App shell — design/app-shell (r1)
**Boards**: Shell-Organizer, Shell-Dense (⌘K), Shell-Overlays, Shell-Participant, Shell-Judge, Shell-Mobile
**Standalone HTML**: `html/` · **Screenshots**: `screenshots/` · **Live source**: `../../exports/r1/canvas/project/`

## Must preserve
- Top bar + rail + right inspector for operators; top-bar-only for participant/judge; ≤5-item bottom nav + More sheet on mobile.
- Event switcher (current/favorites/recent), ⌘K palette with selection-parameterized commands, notification center with actionable rows, account menu with role switch + read-only preview-as + density + shortcuts.
- Overview is a *queue strip + needs-attention table*, not KPI cards; every figure links to filtered records.
- Live ops mode shows connection health and data age.

## Adaptable implementation details
- Exact rail width/labels (follow `roleDestinations`), icon choice, which widgets appear on Overview (saved-view driven).
- Palette ranking algorithm, notification grouping.

## Keyboard / focus / a11y
- Skip link first; rail is `nav` with aria-current; palette is dialog with listbox; `?` opens shortcuts; G-then-letter navigation.

## Known limitations
- Static comps; no real routing. Collapse/expand animation not shown.
